package src.main.resources.script

import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.msglog.MessageLog
// import org.slf4j.LoggerFactory
import java.io.StringWriter
import java.io.PrintWriter
import groovy.json.JsonSlurper
import src.main.resources.script.Constants

class Framework_ExceptionHandler {
    Message message
    MessageLog messageLog
    Map error = [
    	className: "",
    	statusCode: 500,
    	message: "Internal Server Error",
    	details: "",
    	exceptionMessage: "",
    	requestUri: "",
    	stackTrace: "",
    	headers: null,
    	hasRetry: false,
    ]

    static adapterExceptions = [
        "HTTP": [
            "org.apache.camel.component.ahc.AhcOperationFailedException": "handleHttpAdapterException"
        ],
        "OData V2": [
            "com.sap.gateway.core.ip.component.odata.exception.OsciException": "handleODataV2AdapterException",
            "com.sap.gateway.core.ip.component.exception.ODataProcessingException": "handleODataV2AdapterException",
            "org.apache.olingo.odata2.api.exception.ODataApplicationException": "handleODataV2AdapterException",
            "org.apache.olingo.odata2.api.uri.UriNotMatchingException": "handleODataV2AdapterException"
        ],
        // "SOAP": [
        //     "org.apache.cxf.binding.soap.SoapFault": "handleSOAPAdapterException"
        // ],
    ]

    Framework_ExceptionHandler(Message message, MessageLog messageLog) {
        this.message = message
        this.messageLog = messageLog
        setErrorProperties()
    }

    /**
     * Unified method to set message properties, custom headers, and optionally log.
     * In the iFlow log scripts, call this with `handleError(true)` to log,
     * or `handleError(false)` to just parse & set props.
     */
    def handleError(boolean shouldLog = false, String tracePoint = "ERROR") {
    	try {
	        // Set message properties
	        message.setProperty("log_statusCode", error.statusCode.toString())
	        message.setProperty("log_exceptionClass", error.className)
	        if (!error.message || error.message != error.exceptionMessage) {
	        	message.setProperty("log_exceptionMessage", error.exceptionMessage)
        	}
	        
	        // Add custom headers if we have a messageLog
	        if (messageLog) {
	        	messageLog.addCustomHeaderProperty("error_message", error.message ?: error.exceptionMessage)
	            messageLog.addCustomHeaderProperty("error_exceptionClass", error.className)
	            messageLog.addCustomHeaderProperty("error_statusCode", error.statusCode.toString())
				messageLog.addCustomHeaderProperty("error_exceptionMessage", error.exceptionMessage)
	        }

	        // If we want to log, do it now
	        if (shouldLog) {
	            def logger = new Framework_Logger(message, messageLog)
	            logger.logMessage(tracePoint, "ERROR", error.message ?: "Unknown error")
	        }
    	} catch (Exception e) {
    		Framework_Logger.handleScriptError(message, messageLog, e, "Framework_ExceptionHandler.handleError", true)
    	}
    }

    def Map getErrorDetails() {
    	return this.error
    }

    private void setErrorProperties() {
        error.hasRetry = toBool(message.getProperty(Constants.Property.SAP_IS_REDELIVERY_ENABLED))
        error.headers = message.getHeaders()

        def ex = message.getProperty(Constants.Property.CAMEL_EXC_CAUGHT)
        if (ex != null) {
            error.className = ex.getClass().getCanonicalName()
            error.message = ex.getMessage() ?: error.message
            error.exceptionMessage = ex.getMessage()

            // Possibly override statusCode and cleanup message for validation errors
            if (error.message?.contains(Constants.ILCD.Validator.EXC_CLASS)) {
				error.message = error.message.replace(Constants.ILCD.Validator.EXC_MSG_PREFIX, "").trim()
                error.statusCode = 400
                message.setHeader(Constants.Header.CAMEL_RESPONSE_CODE, "400")
                error.className = Constants.ILCD.Validator.EXC_CLASS
            }

    		// Use adapter handlers to parse error details
    		adapterExceptions.each { adapter, exceptions ->
    			if (exceptions.containsKey(error.className)) {
    				def methodName = exceptions.get(error.className)
    				this."$methodName"(ex)
    			}
    		}
    	}

        // Also read the CamelHttpResponseCode
        def existingCode = error.headers.get(Constants.Header.CAMEL_RESPONSE_CODE) 
            ?: message.getHeaders().get(Constants.Header.CAMEL_RESPONSE_CODE)
            ?: message.getProperty(Constants.Header.CAMEL_RESPONSE_CODE)
        if (existingCode) {
            error.statusCode = existingCode.toString().isInteger() ? existingCode.toInteger() : 500
        }

        // Store in message for further steps
        message.setProperty("errorResponseMessage", error.message)
        message.setProperty("errorStatusCode", error.statusCode)
        message.setProperty("errorExceptionMessage", error.exceptionMessage)
        message.setProperty("errorExceptionClass", error.exceptionClass)
    }
    
    private void handleHttpAdapterException(Exception ex) {
    	// Status Code
    	def statusCode = ex.getStatusCode()
    	def headerCode = message.getHeaders().get(Constants.Header.CAMEL_RESPONSE_CODE)?.toString()
    	error.statusCode = statusCode ?: headerCode ?: error.statusCode

    	// Error Message
    	def body = ex.getResponseBody()
    	if (body && body.trim().length() > 0) {
    		error.message = parseMessageFromBody(body) ?: error.message
    	}

    	// Status Text
    	error.details = ex?.getStatusText() ?: ""
    }

    private void handleODataV2AdapterException(Exception ex) {
    	// Status Code
	    def camelCode = message.getHeaders().get(Constants.Header.CAMEL_RESPONSE_CODE)?.toString()
	    error.statusCode = camelCode ? camelCode : error.statusCode

	    // Error Message (from body)
	    def body = message.getBody(String)
	    if (body && body.trim().length() > 0) {
	    	error.message = parseMessageFromBody(body) ?: error.message
	    }

	    // Requested URI
	    error.requestUri = ex.getRequestUri()

	    // Details
	    error.details = ex.getLocalizedMessage() ?: ex.getHttpStatus() ?: ex.getErrorCode()
    }

	def String parseMessageFromBody(String body) {
		def errMsgField = Constants.ILCD.ExceptionHandler.ERROR_RESPONSE_MSG_FIELD
		def userSpecifiedFieldName = message.getProperty(Constants.ILCD.ExceptionHandler.USER_PROVIDED_FIELD_TO_PARSE) ?: ""
	    def messages = []
    	if (body.startsWith('{')) {
    		try {
    			def json = new JsonSlurper().parseText(body)

	            // JSON structure: Recursively find "message" fields and add to messages list
	            def findMessages
	            findMessages = { node ->
	                if (node instanceof Map) {
	                    node.each { key, value ->
	                        if (value instanceof String &&
	                        	(key.equalsIgnoreCase(errMsgField) || key.equalsIgnoreCase(userSpecifiedFieldName))) {
	                            // Check that the same message hasn't been added already
	                            if (!messages.contains(value)) {
	                            	messages.add(value)
	                            }
	                        }
	                        findMessages(value)
	                    }
	                } else if (node instanceof List) {
	                    node.each { findMessages(it) }
	                }
	            }
	            findMessages(json)

			} catch (Exception e) {}
    	} else if (body.startsWith('<')) {
	        try {
	            def xml = new XmlSlurper().parseText(body)

	            xml.depthFirst().findAll { node -> 
	            	node.name().equalsIgnoreCase(errMsgField) || node.name().equalsIgnoreCase(userSpecifiedFieldName)
	            }.each { node -> 
		            if (node.children().isEmpty()) {
                        // Check that the same message hasn't been added already
                        if (!messages.contains(node.text())) {
                        	messages.add(node.text())
                        }
		            } else if (node.value?.children()?.isEmpty()) {
		            	messages.add(node.value.text())
		            }
	            }
	        } catch (Exception e) {}
    	}

	    return messages.join(", ")
	}

    // private void handleSOAPAdapterException(Exception ex) {
	//     def messageLog = messageLogFactory.getMessageLog(message)

	//     // Fault Detail Element
	//     def xml = XmlUtil.serialize(ex.getOrCreateDetail())
	//     messageLog.addAttachmentAsString("http.response", xml, "application/xml")

	//     message.setProperty("http.response", ex.getMessage())
	//     message.setProperty("http.statusCode", ex.getStatusCode())

	//     setErrorProperties(ex.getStatusCode(), ex.getStatusCode(), ex.getMessage())
    // }

    def static String getStackTrace(Exception e) {
        try {
            StringWriter sw = new StringWriter()
            PrintWriter pw = new PrintWriter(sw)
            e.printStackTrace(pw)
            return sw.toString()
        } catch (Exception innerEx) {
            // LoggerFactory.getLogger("Framework_ExceptionHandler").error("Error generating stack trace: ${innerEx.message}", innerEx)
            return "Error generating stack trace: ${innerEx.message}"
        }
    }

    boolean toBool(Object rawValue) {
        if (rawValue == null) return false 
        if (rawValue instanceof Boolean) return (Boolean) rawValue
        return Boolean.parseBoolean(rawValue.toString())
    }
}